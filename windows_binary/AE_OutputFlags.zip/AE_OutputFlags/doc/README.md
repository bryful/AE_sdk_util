﻿# AE_sdk_util
After Effects SDKで必要な**Output Flags**と**Version**を計算するアプリです。<br>
<br>
![ae_sdk_util](AE_OutputFlags.png)<br>
<br>
.Net core5にプラットフォームを変えました。<br>
AE2020以降にも対応できるようにしました。<br>
**Import_AE_EffectH**で、**AE_Effect.ｈ**を読み込んで使用します。<br>
<br>
## Usage
特に説明しなく大丈夫と思います。<br>
**AE_Version**は**show Version Dialog**から表示させます。<br>
<br>
実行には.NetCore5のランタイムライブラリのインストールが必要です。<br>
<br>

## License
This software is released under the MIT License, see LICENSE.<br>

## Authors

bry-ful(Hiroshi Furuhashi)<br>
twitter:bryful<br>
bryful@gmail.com<br>

# References
